package pt.isel.poo.tile;

/**
 *
 */
public interface OnBeatListener {
    void onBeat(long beat, long time);
}
